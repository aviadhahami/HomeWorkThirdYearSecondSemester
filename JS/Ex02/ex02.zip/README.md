**Ex02 - Mobile apps course**

Hi!
This app is written in _ReactJS_ thus it's written mainly in ES6.

I'm submitting the 'production-ready' version and attaching the source 
code (all the components, webpack.config etc.) in case you would like to 
 see them.
 
 Enjoy!