/**
 * Created by aviad on 6/8/2016.
 */
'use strict';
module.exports = [
	'A person is smart. People are dumb, panicky dangerous animals and you know it. Fifteen hundred years ago everybody knew the Earth was the center of the universe. Five hundred years ago, everybody knew the Earth was flat, and fifteen minutes ago, you knew that humans were alone on this planet. Imagine what you\'ll know tomorrow.',
	'I love bad bitches that\'s my fucking problem',
	'Only dead fish flow with the stream'
];