/**
 * Created by aviad on 6/8/2016.
 */
'user strict';
module.exports = {

	// Randomizes a number between s and e
	random: (s, e)=> Math.floor(Math.random() * e + s)
};