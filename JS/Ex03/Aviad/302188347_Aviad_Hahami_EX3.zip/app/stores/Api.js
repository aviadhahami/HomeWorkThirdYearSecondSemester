/**
 * Created by aviad on 6/8/2016.
 */
import {createAPI} from 'cartiv';
let API = createAPI();
export default API;